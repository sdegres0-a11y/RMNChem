/*
 * check_db.c -- verification de coherence de chem_db.h sur PC
 *
 *   cc -std=c11 -Wall -o check_db tools/check_db.c && ./check_db
 *
 * Ce programme ne tourne pas sur la calculatrice. Il sert a attraper les
 * fautes de frappe dans la base avant de flasher le .g3a :
 *   - nombre de C, O, N conforme aux indices a, c, d
 *   - somme des H portes par les atomes = b
 *   - somme des integrations du spectre = b
 *   - valence correcte de chaque atome (C 4, O 2, N 3)
 *   - graphe connexe
 *   - index de liaison et d'attribution valides
 */

#include <stdio.h>
#include <string.h>
#include "../src/chem_db.h"

static int errors = 0;

static void fail(const molecule_t *m, const char *what, int got, int want)
{
	printf("  [ERREUR] %-22s %s : %d (attendu %d)\n", m->name, what,
	       got, want);
	errors++;
}

/* union-find minimal pour tester la connexite */
static int parent[16];
static int find(int x) { return parent[x] == x ? x : (parent[x] = find(parent[x])); }
static void uni(int a, int b) { parent[find(a)] = find(b); }

int main(void)
{
	int i, j, nattr = (int)(sizeof(ATTR) / sizeof(ATTR[0]));

	printf("Verification de %d molecules\n\n", DB_SIZE);

	for(i = 0; i < DB_SIZE; i++) {
		const molecule_t *m = &DB[i];
		int nC = 0, nO = 0, nN = 0, hAtoms = 0, hPeaks = 0;
		int val[16], arom[16];
		int di2;

		memset(val, 0, sizeof(val));
		memset(arom, 0, sizeof(arom));
		for(j = 0; j < 16; j++) parent[j] = j;

		if(m->natoms > 16) {
			printf("  [ERREUR] %s : plus de 16 atomes, les champs de "
			       "bits de bond_t ne suffisent plus\n", m->name);
			errors++;
			continue;
		}

		for(j = 0; j < m->natoms; j++) {
			const atom_t *a = &m->atoms[j];
			if(a->el == EL_C) nC++;
			else if(a->el == EL_O) nO++;
			else nN++;
			hAtoms += a->nH;
			val[j] += a->nH;
			if(a->nH > 4)
				fail(m, "nH d'un atome > 4", a->nH, 4);
		}

		for(j = 0; j < m->nbonds; j++) {
			const bond_t *b = &m->bonds[j];
			if(b->i == b->j) continue;    /* liaison factice */
			if(b->i >= m->natoms || b->j >= m->natoms) {
				printf("  [ERREUR] %s : liaison %d-%d hors bornes "
				       "(%d atomes)\n", m->name, b->i, b->j,
				       m->natoms);
				errors++;
				continue;
			}
			val[b->i] += b->order;
			val[b->j] += b->order;
			if(b->arom) { arom[b->i]++; arom[b->j]++; }
			uni(b->i, b->j);
		}

		for(j = 0; j < m->npeaks; j++) {
			const nmr_peak_t *p = &m->peaks[j];
			hPeaks += p->nH;
			if(p->attr >= nattr)
				fail(m, "index d'attribution invalide", p->attr,
				     nattr - 1);
			if(p->shift > 200)
				fail(m, "deplacement > 20 ppm", p->shift, 200);
		}

		if(nC != m->a) fail(m, "nombre de C", nC, m->a);
		if(nO != m->c) fail(m, "nombre de O", nO, m->c);
		if(nN != m->d) fail(m, "nombre de N", nN, m->d);
		if(hAtoms != m->b) fail(m, "H portes par les atomes", hAtoms, m->b);
		if(hPeaks != m->b) fail(m, "H integres sur le spectre", hPeaks, m->b);

		/* valences : un carbone aromatique porte une double liaison
		 * dans la forme de Kekule, on la retablit ici */
		for(j = 0; j < m->natoms; j++) {
			const atom_t *a = &m->atoms[j];
			int want = (a->el == EL_C) ? 4 : (a->el == EL_O) ? 2 : 3;
			int got = val[j] + (arom[j] >= 2 ? 1 : 0);
			int k;
			/* Groupe nitro : la forme ecrite est N(+)(=O)-O(-).
			 * L'azote porte 4 liaisons et l'oxygene simplement lie
			 * n'en porte qu'une. Les deux sont corrects. */
			if(a->el == EL_N && got == 4 && arom[j] == 0) continue;
			if(a->el == EL_O && got == 1) {
				int nitro = 0;
				for(k = 0; k < m->nbonds; k++) {
					const bond_t *b = &m->bonds[k];
					int other = -1;
					if(b->i == j) other = b->j;
					else if(b->j == j) other = b->i;
					if(other >= 0 &&
					   m->atoms[other].el == EL_N &&
					   val[other] == 4)
						nitro = 1;
				}
				if(nitro) continue;
			}
			if(got != want) {
				printf("  [ERREUR] %-22s atome %d (%c) valence %d "
				       "au lieu de %d\n", m->name, j,
				       a->el == EL_C ? 'C' : a->el == EL_O ? 'O' : 'N',
				       got, want);
				errors++;
			}
		}

		/* connexite */
		for(j = 1; j < m->natoms; j++) {
			if(find(j) != find(0)) {
				printf("  [ERREUR] %s : atome %d isole du reste\n",
				       m->name, j);
				errors++;
				break;
			}
		}

		/* DI entier et positif */
		di2 = 2 * m->a + 2 + m->d - m->b;
		if(di2 < 0 || (di2 & 1))
			fail(m, "2*DI incoherent", di2, 0);
	}

	/* doublons stricts */
	for(i = 0; i < DB_SIZE; i++)
		for(j = i + 1; j < DB_SIZE; j++)
			if(!strcmp(DB[i].name, DB[j].name)) {
				printf("  [ERREUR] nom en double : %s\n", DB[i].name);
				errors++;
			}

	/* inventaire des groupes d'isomeres */
	printf("\nGroupes d'isomeres :\n");
	for(i = 0; i < DB_SIZE; i++) {
		int n = 0, first = 1;
		for(j = 0; j < DB_SIZE; j++)
			if(DB[j].a == DB[i].a && DB[j].b == DB[i].b &&
			   DB[j].c == DB[i].c && DB[j].d == DB[i].d) {
				if(j < i) { first = 0; break; }
				n++;
			}
		if(first && n > 1) {
			printf("  C%dH%d", DB[i].a, DB[i].b);
			if(DB[i].c) printf("O%d", DB[i].c);
			if(DB[i].d) printf("N%d", DB[i].d);
			printf("  (DI %d) :", (2 * DB[i].a + 2 + DB[i].d - DB[i].b) / 2);
			for(j = 0; j < DB_SIZE; j++)
				if(DB[j].a == DB[i].a && DB[j].b == DB[i].b &&
				   DB[j].c == DB[i].c && DB[j].d == DB[i].d)
					printf(" %s ;", DB[j].name);
			printf("\n");
		}
	}

	printf("\nEmpreinte des donnees :\n");
	{
		size_t total = sizeof(DB);
		int na = 0, nb = 0, np = 0;
		for(i = 0; i < DB_SIZE; i++) {
			na += DB[i].natoms; nb += DB[i].nbonds; np += DB[i].npeaks;
		}
		printf("  table maitresse : %zu octets (%d entrees)\n",
		       total, DB_SIZE);
		printf("  atomes  : %d x %zu = %zu octets\n", na, sizeof(atom_t),
		       na * sizeof(atom_t));
		printf("  liaisons: %d x %zu = %zu octets\n", nb, sizeof(bond_t),
		       nb * sizeof(bond_t));
		printf("  signaux : %d x %zu = %zu octets\n", np,
		       sizeof(nmr_peak_t), np * sizeof(nmr_peak_t));
	}

	printf("\n%s (%d erreur%s)\n", errors ? "ECHEC" : "OK",
	       errors, errors > 1 ? "s" : "");
	return errors ? 1 : 0;
}
