#!/usr/bin/env python3
"""Rejoue le journal de dessin du faux gint et produit un PNG par frame."""
import sys
from PIL import Image, ImageDraw, ImageFont

W, H = 396, 224
CW, CH = 8, 9          # cellule de caractere du font gint par defaut

FONT = ImageFont.truetype(
    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 11)


def rgb565(v):
    if v < 0:
        return None
    return (((v >> 11) & 31) * 255 // 31,
            ((v >> 6) & 31) * 255 // 31,
            (v & 31) * 255 // 31)


def run(logfile, prefix):
    img = Image.new("RGB", (W, H), "white")
    dr = ImageDraw.Draw(img)
    n = 0
    for line in open(logfile):
        p = line.rstrip("\n").split(" ")
        op = p[0]
        if op == "CLEAR":
            c = rgb565(int(p[1])) or (255, 255, 255)
            dr.rectangle([0, 0, W, H], fill=c)
        elif op == "LINE":
            dr.line([int(p[1]), int(p[2]), int(p[3]), int(p[4])],
                    fill=rgb565(int(p[5])))
        elif op == "RECT":
            dr.rectangle([int(p[1]), int(p[2]), int(p[3]), int(p[4])],
                         fill=rgb565(int(p[5])))
        elif op == "PIXEL":
            dr.point([int(p[1]), int(p[2])], fill=rgb565(int(p[3])))
        elif op == "TEXT":
            x, y, fg, bg, ha, va = (int(v) for v in p[1:7])
            s = " ".join(p[7:])
            w, h = CW * len(s), CH
            if ha == 1:
                x -= w // 2
            elif ha == 2:
                x -= w
            if va == 1:
                y -= h // 2
            elif va == 2:
                y -= h
            if bg >= 0:
                dr.rectangle([x, y, x + w - 1, y + h - 1], fill=rgb565(bg))
            for i, ch in enumerate(s):
                dr.text((x + i * CW, y - 1), ch, font=FONT, fill=rgb565(fg))
            if x < 0 or x + w > W:
                print(f"  debordement horizontal : '{s}' -> [{x}, {x+w}]")
            if y < 0 or y + h > H:
                print(f"  debordement vertical   : '{s}' -> [{y}, {y+h}]")
        elif op == "UPDATE":
            img.save(f"{prefix}_{n:02d}.png")
            n += 1
    print(f"  {n} frames ecrites")


if __name__ == "__main__":
    run(sys.argv[1], sys.argv[2])
