/* Faux gint : journalise les appels de dessin, pour rendu PNG cote Python. */
#include <stdio.h>
#include <stdlib.h>
#include "gint/display.h"
#include "gint/keyboard.h"

int addin_main(void);

static FILE *out;
static int frame = 0;

void dclear(int c)              { fprintf(out, "CLEAR %d\n", c); }
void dupdate(void)              { fprintf(out, "UPDATE %d\n", frame++); }
void dline(int a,int b,int c,int d,int e) { fprintf(out,"LINE %d %d %d %d %d\n",a,b,c,d,e); }
void drect(int a,int b,int c,int d,int e) { fprintf(out,"RECT %d %d %d %d %d\n",a,b,c,d,e); }
void dpixel(int a,int b,int c)  { fprintf(out, "PIXEL %d %d %d\n", a, b, c); }

void dtext(int x,int y,int fg,const char *s)
{
	fprintf(out, "TEXT %d %d %d %d 0 0 %s\n", x, y, fg, C_NONE, s);
}

void dtext_opt(int x,int y,int fg,int bg,int ha,int va,const char *s,int n)
{
	(void)n;
	fprintf(out, "TEXT %d %d %d %d %d %d %s\n", x, y, fg, bg, ha, va, s);
}

/* Scenario de touches, fourni par la ligne de commande */
static int script[64], nscript = 0, iscript = 0;

key_event_t getkey(void)
{
	key_event_t e;
	if(iscript >= nscript) { fflush(out); exit(0); }
	e.key = script[iscript++];
	return e;
}

int main(int argc, char **argv)
{
	int i;
	out = fopen(argv[1], "w");
	for(i = 2; i < argc; i++) script[nscript++] = atoi(argv[i]);
	addin_main();
	fflush(out);
	return 0;
}
