#ifndef SIM_KEYBOARD_H
#define SIM_KEYBOARD_H
typedef struct { int key; } key_event_t;
enum { KEY_F1=1,KEY_F2,KEY_F3,KEY_F4,KEY_F5,KEY_F6,
       KEY_UP,KEY_DOWN,KEY_LEFT,KEY_RIGHT,KEY_EXE,KEY_EXIT,KEY_DEL,
       KEY_0=100,KEY_1,KEY_2,KEY_3,KEY_4,KEY_5,KEY_6,KEY_7,KEY_8,KEY_9 };
key_event_t getkey(void);
#endif
