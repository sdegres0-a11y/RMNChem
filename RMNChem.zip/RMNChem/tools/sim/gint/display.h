/* Faux gint pour simulation PC -- ne fait pas partie de l'add-in */
#ifndef SIM_DISPLAY_H
#define SIM_DISPLAY_H
#include <stdint.h>
#define DWIDTH  396
#define DHEIGHT 224
#define C_RGB(r,g,b) (((r)<<11)|((g)<<6)|(b))
#define C_WHITE 0xFFFF
#define C_BLACK 0x0000
#define C_RED   0xF800
#define C_GREEN 0x07C0
#define C_BLUE  0x001F
#define C_NONE  (-1)
#define DTEXT_LEFT 0
#define DTEXT_CENTER 1
#define DTEXT_RIGHT 2
#define DTEXT_TOP 0
#define DTEXT_MIDDLE 1
#define DTEXT_BOTTOM 2
void dclear(int c);
void dupdate(void);
void dline(int x1,int y1,int x2,int y2,int c);
void drect(int x1,int y1,int x2,int y2,int c);
void dpixel(int x,int y,int c);
void dtext(int x,int y,int fg,const char *s);
void dtext_opt(int x,int y,int fg,int bg,int ha,int va,const char *s,int n);
#endif
